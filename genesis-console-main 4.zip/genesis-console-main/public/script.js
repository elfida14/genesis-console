const CREDENTIALS = {
  username: "Baki",
  password: "313"
};

function login() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (username === CREDENTIALS.username && password === CREDENTIALS.password) {
    document.getElementById("login-status").innerText = "✅ Accesso consentito, benvenuto Baki!";
    document.getElementById("control-panel").style.display = "block";
    document.getElementById("login-section").style.display = "none";
  } else {
    document.getElementById("login-status").innerText = "❌ Credenziali errate. Riprova.";
  }
}

async function sendCommand() {
  const command = document.getElementById("command").value.trim();
  const status = document.getElementById("device-status");
  const response = document.getElementById("ai-response");

  if (!command) {
    response.innerText = "⚠️ Nessun comando inviato.";
    return;
  }

  status.innerText = `⏳ Invio comando: "${command}"...`;
  response.innerText = "";

  try {
    const res = await fetch('/command', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ type: 'command', data: command })
    });

    const data = await res.json();
    if (res.ok) {
      response.innerText = `🤖 Genesis: ${data.response || "Nessuna risposta."}`;
      status.innerText = "✅ Comando eseguito con successo.";
    } else {
      response.innerText = `⚠️ Errore: ${data.error || 'Risposta non valida.'}`;
      status.innerText = "❌ Comando non eseguito.";
    }
  } catch (err) {
    response.innerText = `❌ Errore di comunicazione: ${err.message}`;
    status.innerText = "❌ Comando non eseguito.";
  }
}

// Invio comando anche con Invio da tastiera
document.addEventListener("keydown", function (e) {
  if (e.key === "Enter") {
    if (document.getElementById("control-panel").style.display === "block") {
      sendCommand();
    }
  }
});
