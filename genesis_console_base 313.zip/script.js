function sendCommand() {
  fetch('/api/command', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ command: 'ATTIVA_LUCE_VITA' })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('console-output').innerText += '\n' + data.response;
  });
}
