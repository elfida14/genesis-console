const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/api/command', (req, res) => {
  const { command } = req.body;
  console.log("Comando ricevuto:", command);
  let response = `Comando "${command}" ricevuto. Modulo spirituale attivo.`;
  res.json({ response });
});

app.get('/', (req, res) => {
  res.send("Genesis Console Backend Attivo");
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Backend in ascolto su porta ${PORT}`);
});
